package simpleCal;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class Counttest {

	@Test
	void test() {
		Calculation test=new Calculation();
	    int result=test.countA("Pabita");
		assertEquals(2,result);
		}
}
