package simpleCal;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class Multiplytest {

	@Test
	void test() {
	Calculation test=new Calculation();
	int result=test.multiply(2,7);
	assertEquals(14,result);
	}

}
