package simpleCal;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class Squaretest {

	@Test
	void test() {
		Calculation test=new Calculation();
		int result=test.square(7);
		assertEquals(49,result);
		}
}
